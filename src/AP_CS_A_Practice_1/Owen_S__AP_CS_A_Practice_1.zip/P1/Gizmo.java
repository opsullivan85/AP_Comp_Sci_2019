package AP_CS_A_Practice_1.P1;

public class Gizmo{

    /** Returns the name of the manufacturer of this Gizmo. */
    public String getMaker(){
        /* implementation not shown */
        return null;
    }

    /** Returns true if this Gizmo is electronic, and false
     *  otherwise.
     */
    public boolean isElectronic(){
        /* implementation not shown */
        return false;
    }

    /** Returns true if this Gizmo is equivalent to the Gizmo
     *  object represented by the
     *  parameter, and false otherwise.
     */
    public boolean equals(Object other){
        /* implementation not shown */
        return false;
    }

    /** There may be instance variables, constructors, and
     *  methods not shown.
     */

}

