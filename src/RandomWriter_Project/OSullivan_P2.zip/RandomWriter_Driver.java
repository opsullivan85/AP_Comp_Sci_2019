package RandomWriter_Project;

public class RandomWriter_Driver {
    public static void main(String[] args){
        RandomWriter rw = new RandomWriter();
    }
}
