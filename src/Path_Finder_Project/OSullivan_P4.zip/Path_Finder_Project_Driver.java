package Path_Finder_Project;

public class Path_Finder_Project_Driver {
    public static void main(String[] args) {
        Main main = new Main();
        main.run();
    }
}
